package SoprAjc.AgenceVoyageSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgenceVoyageSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
